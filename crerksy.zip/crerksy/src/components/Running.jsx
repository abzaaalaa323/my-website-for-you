export default function Running() {
    return (
        <>
            <section className="flex items-center justify-between h-screen ">
                <nav className="text-white">
                    <h1 className="font-recoleta font-semibold text-[48px]">
                        Running the show <br /> has never been so <br /> easy.
                    </h1>
                    <p className="mt-4 text-lg ">
                        Ready to put the human back in HR? Clerksy helps you  set the stage  with an inclusive and compliant  <br /> workplace.
                    </p>
                </nav>

                <img src="/logo2.svg" alt="" className="w-[1540px] translate-x-[80px] relative -top-4 " />


            </section>
        </>
    )
}