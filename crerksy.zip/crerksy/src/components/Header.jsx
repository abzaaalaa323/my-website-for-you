import { NavLink, useLocation } from "react-router-dom";

export default function Stranica1() {
    const location = useLocation();
    const userName = location.state ? location.state.name : null;

    return (
        <div>
            <header className="flex items-center justify-between">
                <NavLink to="/Clerksy">
                    <button>
                        <img src="/logo.svg" alt="" />
                    </button>
                </NavLink>
                <nav className="text-white flex items-center gap-10">
                    <a href="#">Ale</a>
                    <a href="#">87471110900</a>
                    {userName && <span className="text-white">{`Привет, ${userName}`}</span>}
                    <NavLink to="/sigh">
                        <button className="bg-[#198C36] px-6 py-2 rounded-full">Sign up</button>
                    </NavLink>
                </nav>
            </header>
        </div>
    );
}
