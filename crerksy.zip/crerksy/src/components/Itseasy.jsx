export default function Itseasy() {
    return (
        <>
            <div className="bg-[#F2EFE6] text-[#163A24]">
                <div className=" flex flex-col pt-[80px]">
                    <h1 className="font-recoleta font-semibold text-[48px] text-center">It's easy as 1, 2, 3</h1>
                    <p className="font-recoleta mt-4 text-lg text-center">Clerksy can help use your unique business needs. Here's how:</p>
                </div>
                <div className="flex justify-around pt-[80px] font-recoleta text-lg">
                    <div className="flex gap-20">
                        <div className="text-center">
                            <p>Fill out a form and tell us what <br /> you're looking for:</p>
                            <p className="text-2xl font-bold mt-2">5 minutes</p>
                        </div>
                        <img src="./Group1.svg" alt="" />
                        <div className="text-center">
                            <p>Time it will take a Clerksy rep <br /> to follow up:</p>
                            <p className=" text-2xl font-bold mt-2"> 24 hours</p>
                        </div>
                        <img src="./Group2.svg" alt="" />
                        <div className="text-center relative ">
                            <img src="./Vector.svg" alt="" className="absolute" />

                            <p>Take advantage of our <br /> monthly plans starting at:</p>
                            <p className=" text-2xl font-bold mt-2">$969 USD</p>

                        </div>
                    </div>
                </div>
                <div className="pt-[40px] flex justify-center items-center">
                    <button className=" bg-[#198C36] px-6 py-3 rounded-full center text-white">Book Free Discovery Call</button>
                </div>
                <div className="pt-[90px]"></div>

            </div>
        </>
    )
}