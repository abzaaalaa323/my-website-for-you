export default function Emploees() {
    return (
        <div className="flex flex-col items-center justify-center pt-[80px] text-[#163A24]">
            <h1 className="font-recoleta font-semibold text-[48px] text-center">
                Employees come in all shapes and <br /> sizes. Find the right fit.
            </h1>

            <p className="mt-4 text-lg text-center">
                Focus on casting and screening. Let Clerksy handle contracts, resolve any on-set conflicts <br />
                and make sure you are compliant with work and safety boards.
            </p>

            <img src="./pic.svg" alt="" className="mt-8 mx-auto" />
            <div className="pt-[120px]"></div>
        </div>

    )
}
