export default function HRProduction() {
    return (
        <div className=" pt-[70px] font-recoleta" >
            <h1 className="  text-center text-4xl font-semibold text-white">HR Production of the Highest Qualityt</h1>
            <div className="flex justify-around pt-[80px] text-white">
                <div className="flex gap-40" >
                    <div className="flex flex-col items-center text-center space-y-2">
                        <img src="./main1.1.svg" alt="" />
                        <p>Educates & Informs</p>
                        <p>Employee Expectations</p>
                    </div>
                    <div className="flex flex-col items-center text-center space-y-2">
                        <img src="./main1.2.svg" alt="" />
                        <p>Protects Your Business</p>
                        <p>Just in Case</p>
                    </div>
                    <div className="flex flex-col items-center text-center space-y-2">
                        <img src="./main1.3.svg" alt="" />
                        <p>Manages & Stores</p>
                        <p>Important Documents</p>
                    </div>
                    <div className="flex flex-col items-center text-center space-y-2">
                        <img src="./main1.4.svg" alt="" />
                        <p>Create a Healthy</p>
                        <p>Work Environment</p>
                    </div>
                </div>
            </div>
            <div className="pt-[80px]"></div>
        </div>
    )
}