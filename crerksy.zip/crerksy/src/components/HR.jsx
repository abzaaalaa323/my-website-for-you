export default function HR() {
    return (
        <>
            <div className="">
                <div className="flex items-center justify-around pt-[80px] text-[#163A24]">
                    <img src="/strphoto.svg" alt=" " />
                    <nav className="">
                        <h1 className="font-recoleta font-semibold text-[48px] text-black">
                            Put the human <br /> back in HR.
                        </h1>
                        <p className="text-black mt-4 text-lg ">
                            Your employees are the real stars. Show the <br />  love and help them perform!
                        </p>
                    </nav>
                </div>

                <div className="flex items-center justify-around pt-[80px">
                    <nav className="">
                        <h1 className="font-recoleta font-semibold text-[48px] text-black">
                            Put the human <br /> back in HR.
                        </h1>
                        <p className="text-black mt-4 text-lg ">
                            Your employees are the real stars. Show the <br /> love and help them perform!
                        </p>
                    </nav>
                    <img src="/strphoto2.svg" alt="" />

                </div>

                <div className="center pt-[100px]">
                    <h1 className=" font-recoleta font-semibold text-center text-4xl text-[#163A24]">We partner with the best</h1>
                    <div className="flex justify-center gap-20 pt-[60px]" >
                        <img src="./Rectangle1.svg" alt="" />
                        <img src="./Rectangle2.svg" alt="" />
                        <img src="./Rectangle3.svg" alt="" />
                        <img src="./Rectangle4.svg" alt="" />
                        <img src="./Rectangle5.svg" alt="" />
                    </div>
                </div>
                <div className="pt-[80px]">
                </div>

            </div>
        </>
    )
}