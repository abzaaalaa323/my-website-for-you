export default function Mm() {
    return (
        <>
            <div className="flex items-center justify-around pt-[60px] bg-[#F2EFE6] ">
                <div className="">
                    <h1 className="font-recoleta font-semibold text-[60px]">Stay up to date!</h1>
                    <p className="mt-4 text-lg">Sign up for the latest Clerksy news.</p>
                </div>
                <div className="">
                    <div className="mt-8 flex items-center bg-white rounded-full shadow-md overflow-hidden  " >

                        <button className="bg-[#198C36] text-white px-10 py-3 font-semibold ">
                            Sign Up
                        </button>
                    </div>
                    <p className="pt-[20px]">By submitting your email you agree to receive updates about Clerksy. You can <br /> unsubscribe at any time. View our full Privacy Policy{" "}
                        <a href="#" className="text-[#198C36] underline">
                            Privacy Policy
                        </a> </p>

                </div>

                <div className="pt-[90px]"></div>


            </div>

            <div className="bg-white pt-[60px]">
                <div className="flex items-center justify-around">
                    <div>
                        <img src="/suret.svg" alt="" />
                    </div>
                    <h1 className="center text-[25px] font-recoleta font-semibold">A people company.</h1>
                    <div className="text-white flex items-center gap-4">
                        <img src="./suret2.svg" alt="" />
                        <img src="./suret3.svg" alt="" />
                        <img src="./suret4.svg" alt="" />
                        <img src="./suret5.svg" alt="" />

                    </div>
                </div>
                <div className="flex items-center justify-around pt-[60px]">
                    <h1>© 2020 Clerksy, Inc. Clerksy is a registered trademark of Clerksy, Inc.</h1>
                    <div className="text-[#198C36] flex items-center gap-4">
                        <a href="#">Privacy Policy</a>
                        <a href="#">Terms of Service</a>
                        <a href="#">GDPR</a>
                        <a href="#">Careers</a>
                        <a href="#">Press Kit</a>
                    </div>

                </div>


            </div>
        </>
    )
}