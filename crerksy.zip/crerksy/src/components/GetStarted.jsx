export default function Bet1() {
    return (
        <>
            <div className="pt-[70px] relative">

                <div className=" center items-center justify-center justify-between bg-[#163A24] h-[500px]">
                    <div className="  flex justify-between ">
                        <img className="absolute bottom-0" src="./gg.svg" alt="" />
                        <img className="absolute bottom-0 right-0" src="./ggg.svg" alt="" />
                    </div>
                    <div className="center items-center text-white">
                        <h1 className="font-recoleta font-semibold text-[48px] text-center pt-[150px]">
                            Get Started With Clerksy
                        </h1>
                        <p className=" mt-4 text-lg text-center">
                            Make sure your business puts people first.
                        </p>
                    </div>
                    <div className="pt-[30px] flex justify-center items-center ">
                        <button className=" bg-[#FAB5A0] px-6 py-3 rounded-full center text-black">Book Free Discovery Call</button>
                    </div>
                    <div className="pt-[100px]  "></div>
                </div>


            </div>
        </>
    )
}