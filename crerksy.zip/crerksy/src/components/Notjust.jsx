export default function Bet() {
    return (
        <>
            <div className="flex items-center justify-around pt-[80px] ">
                <div className="">
                    <h1 className="font-recoleta font-semibold text-[60px]">Not just another <br /> HR resource.</h1>
                    <p className="mt-4 text-lg">Simple. Entertaining. Informative.</p>
                    <button className=" mt-4 bg-[#198C36] px-6 py-2 rounded-full" >Download E-book</button>
                </div>
                <div>
                    <img src="./Group3.svg" alt="" />
                </div>


            </div>


        </>
    )
}