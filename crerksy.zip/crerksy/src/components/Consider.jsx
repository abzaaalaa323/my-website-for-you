export default function Ai({ dataInfo }) {
    return (
        <div>
            <div className="flex items-center justify-around pt-[80px] text-[#163A24]">
                <div>
                    <h1 className="font-recoleta font-semibold text-[48px] text-black">
                        How the scenes <br /> fit together
                    </h1>
                    <p className="text-black mt-4 text-lg">
                        Employee Training & Development, Diversity <br />
                        & Inclusion Programs, and Conflict <br /> Resolution.
                    </p>
                </div>
                <img src="./characters.svg" alt="characters" className="ml-[-100px]" />
            </div>

            <div className="pt-[80px]"></div>
            <div>
                <div className="text-[#163A24]">
                    <h1 className="font-recoleta font-semibold text-[48px] text-center">
                        Consider everyone's best interest
                    </h1>
                    <p className="font-recoleta mt-4 text-lg text-center">
                        HR is for everyone. Clerksy can help you.
                    </p>
                </div>

                <div className="flex justify-center gap-10 pt-10">
                    {dataInfo.map((data, index) => (
                        <div
                            key={index}
                            className="w-[353px] h-[393px] bg-[#FBFAF7] rounded-[15px] shadow-[5px_5px_20px_0px_#E9E4D5] p-6"
                        >
                            <img
                                src={data.imgUrl}
                                alt="icon"
                                className="w-[52px] h-[65px] mx-auto mt-4"
                            />
                            <h1 className="text-center text-2xl font-recoleta font-bold text-[#163A24] mt-4">
                                {data.title}
                            </h1>
                            <h2 className="text-center text-2xl font-recoleta font-bold text-[#163A24] mt-[-8px]">
                                Company
                            </h2>

                            <ul className="mt-6 space-y-2 text-center text-[#163A24] text-lg">
                                {Object.keys(data).map((key) => {
                                    if (key.startsWith('text') && data[key]) {
                                        return (
                                            <li key={key}>
                                                • {data[key]}
                                            </li>
                                        );
                                    }
                                    return null;
                                })}
                            </ul>
                        </div>
                    ))}
                </div>
            </div>

            <div className="pt-[80px]"></div>
        </div>
    );
}
