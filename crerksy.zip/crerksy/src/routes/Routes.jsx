import { Route, Routes } from "react-router-dom"
import Home from '../pages/Home'
import Sigh from '../pages/sigh'
import Clerksy from "../pages/clerksy"
import Login from "../pages/login"
import Aaa from "../pages/Aaa"

export default function AppRouter() {
    return(
        <Routes>
            <Route path="/" element={<Home />}/>
            <Route path="/sigh" element={<Sigh />}/>
            <Route path="/Clerksy" element={<Clerksy />}/>
            <Route path="/login" element={<Login />}/>
            <Route path="/aaa" element={<Aaa />}/>
        </Routes>
    );
}