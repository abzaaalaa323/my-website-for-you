import { useState } from "react";
import { NavLink, useNavigate } from "react-router-dom";

export default function Aaa() {
    const [formData, setFormData] = useState({ name: "", password: "" });
    const navigate = useNavigate(); // Хук для перенаправления

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.id]: e.target.value });
    };

    const handleSubmit = (e) => {
        e.preventDefault(); // Предотвращаем переход
        if (!formData.name || !formData.password) {
            alert("Пожалуйста, заполните все поля.");
            return;
        }
        // Перенаправляем на главную страницу с переданным именем
        navigate("/", { state: { name: formData.name } });
    };

    return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
            <h1 className="text-2xl font-bold mb-6">Войти в аккаунт</h1>

            <div className="bg-white p-6 rounded-lg shadow-md w-full max-w-sm">
                {/* Name Field */}
                <input
                    type="text"
                    id="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Имя"
                    className="w-full mb-4 px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-[#198C36]"
                />

                {/* Password Field */}
                <input
                    type="password"
                    id="password"
                    value={formData.password}
                    onChange={handleChange}
                    placeholder="Пароль"
                    className="w-full mb-4 px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-[#198C36]"
                />

                <button
                    className="w-full bg-[#198C36] text-white py-2 rounded-lg hover:bg-[#15752D]"
                    onClick={handleSubmit}
                >
                    Войти
                </button>

                <div className="text-center my-4 text-gray-500">или</div>

                <NavLink to={'/'}>
                    <button className="w-full bg-red-500 text-white py-2 rounded-lg hover:bg-red-600">
                        Войти через Google
                    </button>
                </NavLink>
            </div>

            <NavLink to={'/'}>
                <button className="mt-4 text-[#198C36] underline">Отменить</button>
            </NavLink>
        </div>
    );
}
