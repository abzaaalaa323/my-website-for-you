import { NavLink } from "react-router-dom";

export default function Login() {
    return( <>
        <NavLink to={'/'}>
            <button className="bg-[#198C36] px-6 py-2 rounded-full">Вернутся</button>
        </NavLink><h1>старница для регистрации
    
        </h1></>
    )
}