import Header from '../components/Header.jsx'
import Stranica1 from '../components/Running.jsx'
import Stranica2 from '../components/HR.jsx'
import Stranica3 from '../components/HRProduction.jsx'
import Stranica4 from '../components/Employees.jsx'
import Stranica5 from '../components/Consider.jsx'
import Stranica6 from '../components/Itseasy.jsx'
import Stranica7 from '../components/Notjust.jsx'
import Stranica8 from '../components/GetStarted.jsx'
import Stranica9 from '../components/StayUp.jsx'

import { useState, useEffect } from "react"

import axios from "axios"

export default function Home(){const [dataInfo, setDataInfo] = useState([])

useEffect(() => {
  axios.get("https://eff6257bb79201b9.mokky.dev/consider")
  .then((response) => {
    setDataInfo(response.data)
  })
  .catch((error) => {
    console.log(error)
  })

},[])

    return(
        <>
        
    <div className='bg-[#163A24] h-screen h-[680px] px-[130px] py-[20px]'>
      <Header />
      <Stranica1 />
    </div>
    <div className="">
      <Stranica2 />
    </div>
    <div className='bg-[#163A24]'>
      <Stranica3 />
    </div>
    <div className='bg-[#F2EFE6]'>
      <Stranica4 />
    </div>
    <div>
      <Stranica5 dataInfo ={ dataInfo } />
    </div>
    <Stranica6 />
    <Stranica7 />
    <Stranica8 />
    <div>
      <Stranica9 />
    </div>
        </>
    )
}