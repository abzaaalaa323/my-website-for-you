import { useState } from "react";
import { NavLink, useNavigate } from "react-router-dom";

export default function Sigh() {
    const [formData, setFormData] = useState({ name: "", email: "", password: "" });
    const [error, setError] = useState("");
    const navigate = useNavigate();

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.id]: e.target.value });
        setError("");
    };

    const handleSubmit = (e) => {
        e.preventDefault(); 
        if (!formData.name || !formData.email || !formData.password) {
            setError("Пожалуйста, заполните все поля.");
            return;
        }
        if (!formData.email.includes("@")) {
            setError("Введите корректный email с символом '@'.");
            return;
        }
        navigate("/", { state: { name: formData.name } });
    };

    return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-gray-50">
            <div className="absolute top-8 left-8">
                <NavLink to={'/'}>
                    <button className="bg-[#198C36] text-white px-6 py-2 rounded-full hover:bg-[#15782C] transition duration-300">
                        Вернуться
                    </button>
                </NavLink>
            </div>

            <div className="bg-white shadow-lg rounded-lg p-8 max-w-md w-full">
                <h1 className="text-3xl font-bold text-center text-[#198C36] mb-6">
                    Регистрация
                </h1>

                <form className="flex flex-col gap-4" onSubmit={handleSubmit}>
                    <div>
                        <label htmlFor="name" className="block text-gray-700 font-medium mb-1">
                            Полное имя
                        </label>
                        <input
                            type="text"
                            id="name"
                            value={formData.name}
                            onChange={handleChange}
                            placeholder="Введите ваше имя"
                            className="w-full border border-gray-300 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-[#198C36]"
                        />
                    </div>

                    <div>
                        <label htmlFor="email" className="block text-gray-700 font-medium mb-1">
                            Email
                        </label>
                        <input
                            type="email"
                            id="email"
                            value={formData.email}
                            onChange={handleChange}
                            placeholder="Введите ваш email"
                            className="w-full border border-gray-300 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-[#198C36]"
                        />
                    </div>

                    <div>
                        <label htmlFor="password" className="block text-gray-700 font-medium mb-1">
                            Пароль
                        </label>
                        <input
                            type="password"
                            id="password"
                            value={formData.password}
                            onChange={handleChange}
                            placeholder="Введите пароль"
                            className="w-full border border-gray-300 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-[#198C36]"
                        />
                    </div>

                    {error && <p className="text-red-500 text-sm">{error}</p>}

                    <button
                        type="submit"
                        className="bg-[#198C36] text-white py-2 rounded-full hover:bg-[#15782C] transition duration-300"
                    >
                        Зарегистрироваться
                    </button>
                </form>

                <p className="mt-4 text-gray-600 text-center">
                    Уже есть аккаунт?{' '}
                    <NavLink to={'/Aaa'} className="text-[#198C36] font-medium hover:underline">
                        Войти
                    </NavLink>
                </p>
            </div>
        </div>
    );
}
