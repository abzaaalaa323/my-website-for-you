import { NavLink } from "react-router-dom";

export default function Clerksy() {
    return (
        <>
         <div className="absolute top-8 left-8">
                    <NavLink to={'/'}>
                        <button className="bg-[#198C36] text-white px-6 py-2 rounded-full hover:bg-[#15782C] transition duration-300">
                            Вернуться
                        </button>
                    </NavLink>
                </div>
            <div className="flex flex-col items-center justify-around pt-[80px] bg-gray-50 min-h-screen">

                <header className="flex flex-col items-center">
                    <h1 className="text-4xl font-bold text-[#198C36] mb-4">Добро пожаловать в Clerksy!</h1>
                    <p className="text-lg text-gray-700 max-w-[600px] text-center">
                        Clerksy — это инновационная платформа для профессионалов! Мы упрощаем жизнь, работая на результат.
                    </p>
                </header>

                <section className="mt-10 w-full">
                    <h2 className="text-2xl font-semibold text-[#198C36] text-center mb-6">
                        Интересные факты о Clerksy
                    </h2>
                    <div className=" bg-[#FBFAF7] grid grid-cols-1 md:grid-cols-2 gap-8 px-4 max-w-[1000px] mx-auto">
                        <div className="bg-white shadow-lg rounded-lg p-6">
                            <h3 className="text-xl font-medium text-[#163A24] mb-2">Факт №1</h3>
                            <p className="text-gray-600">
                                Название "Clersky" появилось случайно во время вдохновляющей поездки на старой электричке.
                            </p>
                        </div>
                        <div className="bg-white shadow-lg rounded-lg p-6">
                            <h3 className="text-xl font-medium text-[#163A24] mb-2">Факт №2</h3>
                            <p className="text-gray-600">
                                Каждый разработчик Clerksy пьёт в среднем по 3 кружки кофе за день разработки!
                            </p>
                        </div>
                        <div className="bg-white shadow-lg rounded-lg p-6">
                            <h3 className="text-xl font-medium text-[#163A24] mb-2">Факт №3</h3>
                            <p className="text-gray-600">
                                Слоган компании — "Клиенты ценят Clerksy, потому что Clerksy ценит клиентов!".
                            </p>
                        </div>
                        <div className="bg-white shadow-lg rounded-lg p-6">
                            <h3 className="text-xl font-medium text-[#163A24] mb-2">Факт №4</h3>
                            <p className="text-gray-600">
                                На нашей платформе зарегистрировано уже более 10000 довольных пользователей.
                            </p>
                        </div>
                    </div>
                </section>
            </div>
        </>
    );
}
